from django.apps import AppConfig


class DatascienceConfig(AppConfig):
    name = 'Datascience'
